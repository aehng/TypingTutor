The page shows a keyboard with a typing prompt above it. As the user types the prompt is changes color and moves to the next prompt when finished
When a user presses down one or more keys, those keys should appear "pressed" on the onscreen keyboard.
When a user lifts up one or more keys that were pressed, those keys should become "unpressed" on the onscreen keyboard.
When the user presses the shift key, the onscreen keyboard should display the "capitalized" version of each letter/number.
When a user types the underlined letter the letter becomes a different color and the underline moves to the next letter
When the prompt is finished the next prompt shows up
When incorect keys are pressed the underline does not move on
Letters are Case Sensitive
The current underlined character is highlighted on the keyboard
If the next letter needs to be capitalized the Shift key is highlighted before the next letter is highlighted